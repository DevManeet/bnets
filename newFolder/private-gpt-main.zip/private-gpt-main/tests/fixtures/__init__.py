"""Global fixtures."""
