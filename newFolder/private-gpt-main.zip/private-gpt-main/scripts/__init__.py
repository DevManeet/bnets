"""PrivateGPT scripts."""
