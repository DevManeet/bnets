"""general utils."""
