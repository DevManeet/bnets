from pathlib import Path

PROJECT_ROOT_PATH: Path = Path(__file__).parents[1]
